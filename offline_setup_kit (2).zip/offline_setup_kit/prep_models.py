import os
import shutil
from pathlib import Path
from huggingface_hub import snapshot_download

# Configuration
ROOT_DIR = Path(__file__).parent.parent
OFFLINE_ASSETS = ROOT_DIR / "offline_assets"
MODELS_DIR = OFFLINE_ASSETS / "models"
HF_CACHE = MODELS_DIR / "hf_cache"

# Ensure directories exist
os.makedirs(MODELS_DIR, exist_ok=True)
os.makedirs(HF_CACHE, exist_ok=True)

# Set HF_HOME environment variable for the script to use our cache
os.environ["HF_HOME"] = str(HF_CACHE.absolute())

def download_embedding_models():
    print("--- Downloading Embedding Models ---")
    models = ["sentence-transformers/all-MiniLM-L6-v2"]
    for model_id in models:
        print(f"Downloading {model_id}...")
        snapshot_download(
            repo_id=model_id,
            local_dir=MODELS_DIR / model_id.split("/")[-1],
            cache_dir=HF_CACHE
        )

def download_docling_models():
    print("--- Downloading Docling Models ---")
    try:
        from docling.document_converter import DocumentConverter
        from docling.datamodel.pipeline_options import PdfPipelineOptions
        from docling.datamodel.base_models import InputFormat
        from docling.document_converter import PdfFormatOption

        # Trigger download by initializing the converter
        # This will store weights in the HF_HOME (hf_cache)
        print("Initializing Docling (this triggers model downloads)...")
        opts = PdfPipelineOptions()
        opts.do_ocr = True # Download OCR models too
        opts.do_table_structure = True
        
        # We don't actually need to convert a file, just init the models
        converter = DocumentConverter()
        print("Docling models successfully cached in hf_cache.")
    except ImportError:
        print("Error: docling not installed. Please run 'pip install docling' on the internet-connected PC first.")

if __name__ == "__main__":
    download_embedding_models()
    download_docling_models()
    print(f"\nAll models downloaded to {MODELS_DIR}")
    print(f"Transfer the 'offline_assets' folder to your offline PC.")
