import subprocess
import sys
import os
from pathlib import Path

def run_command(command, description):
    print(f"\n--- {description} ---")
    print(f"Running: {' '.join(command)}")
    try:
        result = subprocess.run(command, check=True, capture_output=False)
        return True
    except subprocess.CalledProcessError as e:
        print(f"Error during {description}: {e}")
        return False

def build_offline_bundle():
    # 1. Setup Directories
    # Since this file is in offline_setup_kit/, root is one level up
    root = Path(__file__).parent.parent
    assets_dir = root / "offline_assets"
    wheelhouse_dir = assets_dir / "wheelhouse"
    requirements_path = root / "requirements.txt"
    prep_models_path = Path(__file__).parent / "prep_models.py"
    
    print(f"Targeting: Python 3.13")
    print(f"Project Root: {root.absolute()}")
    print(f"Assets Directory: {assets_dir.absolute()}")
    
    os.makedirs(wheelhouse_dir, exist_ok=True)

    # 2. Download Wheelhouse
    pip_command = [
        sys.executable, "-m", "pip", "download",
        "-r", str(requirements_path),
        "-d", str(wheelhouse_dir),
        "--python-version", "3.13",
        "--only-binary=:all:",
        "--platform", "win_amd64" 
    ]
    
    if not run_command(pip_command, "Downloading Python 3.13 Wheels"):
        print(f"Failed to download wheels. Ensure you have internet and pip installed.")
        return

    # 3. Download Models
    if not prep_models_path.exists():
        print(f"Error: {prep_models_path} not found.")
        return

    model_command = [sys.executable, str(prep_models_path)]
    if not run_command(model_command, "Downloading AI Models"):
        print("Failed to download models.")
        return

    print("\n" + "="*50)
    print("SUCCESS: Offline Assets Ready!")
    print(f"Location: {assets_dir.absolute()}")
    print("="*50)
    print("\nNext Steps:")
    print("1. Copy the entire project folder to your offline PC.")
    print("2. On the offline PC, run:")
    print(f"   pip install --no-index --find-links=./offline_assets/wheelhouse -r requirements.txt")
    print("3. Set the environment variable: $env:OFFLINE_MODE='True'")

if __name__ == "__main__":
    build_offline_bundle()
