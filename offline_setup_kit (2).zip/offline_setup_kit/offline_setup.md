# Offline Setup Guide (Python 3.13)

This guide explains how to package this project for use on a machine without internet access. All tools required for this are located in the `offline_setup_kit/` folder.

## Prerequisites (Internet-Connected Machine)
- **OS**: Must match the target offline machine (Windows 10/11 recommended).
- **Python**: 3.13 must be installed.
- **Space**: Approximately 2-4GB for wheels and AI models.

---

## Step 1: Prepare the Package
Run the "Build Agent" script from the project root. This script automates downloading both the libraries and the AI models.

```powershell
python offline_setup_kit/build_offline_assets.py
```

This will create an `offline_assets/` folder in the project root containing:
- `wheelhouse/`: All `.whl` files for dependencies.
- `models/`: Pre-cached AI models for Embeddings and Docling.

---

## Step 2: Transfer to Offline PC
Copy the entire project folder (including `offline_setup_kit` and the newly created `offline_assets`) to the offline machine via USB or External Drive.

---

## Step 3: Installation (Offline PC)

### 3.1 Install Dependencies
Navigate to the project root and run:
```powershell
pip install --no-index --find-links=./offline_assets/wheelhouse -r requirements.txt
```

### 3.2 Configure Offline Mode
The code is designed to switch to local models when the `OFFLINE_MODE` environment variable is set.

**Windows PowerShell:**
```powershell
$env:OFFLINE_MODE="True"
```

---

## Step 4: Verification
Run the parser to ensure everything works without a connection:
```powershell
python Parsing/pdf_parser_hybrid.py your_test_file.pdf
```
