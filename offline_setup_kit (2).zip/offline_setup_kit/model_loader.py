import os
from pathlib import Path

def get_model_path(model_name: str) -> str:
    """
    Returns a local model path if OFFLINE_MODE is set,
    otherwise returns the remote model name.
    """
    offline_mode = os.environ.get("OFFLINE_MODE", "False").lower() == "true"
    
    if offline_mode:
        # Search in the standard locations
        # Go up one level from this file's folder to find offline_assets in project root
        base_path = Path(__file__).parent.parent / "offline_assets" / "models"
        # Try finding the specific folder (e.g., all-MiniLM-L6-v2)
        local_path = base_path / model_name.split("/")[-1]
        local_path = base_path / mdoel_name.split("/")[-1]
        if local_path.exists():
            print(f"--- [OFFLINE MODE] Using local model: {local_path.absolute()}")
            return str(local_path.absolute())
        else:
            print(f"--- [OFFLINE MODE] WARNING: Could not find local model at {local_path}")
            # Fallback to model_name string and hope HF cache has it
            return model_name
            
    return model_name

def setup_hf_environment():
    """Sets up the HF_HOME if in offline mode."""
    if os.environ.get("OFFLINE_MODE", "False").lower() == "true":
        hf_cache = (Path(__file__).parent.parent / "offline_assets" / "models" / "hf_cache").absolute()
        if hf_cache.exists():
            os.environ["HF_HOME"] = str(hf_cache)
            # Disable internet for HF hub
            os.environ["HF_HUB_OFFLINE"] = "1"
            print(f"--- [OFFLINE MODE] HF_HOME set to {hf_cache}")
